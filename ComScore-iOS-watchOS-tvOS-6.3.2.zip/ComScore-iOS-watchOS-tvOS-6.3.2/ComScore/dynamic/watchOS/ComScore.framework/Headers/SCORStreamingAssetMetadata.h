//
//  Copyright © 2016 comScore. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SCORStreamingAssetMetadata : NSObject

@end
